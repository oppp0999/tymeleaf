rootProject.name = "firstboot"
